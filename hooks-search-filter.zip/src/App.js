import React from "react";

/** components */
import Users from './Users/Users';

export const App = () => {
    return (
        <div>
            <Users />
        </div>
    );
}

export default App;
