import React, { useState, useEffect } from "react";

const names = [
  {
    name: "shakib",
    title: "This is shakib",
    roll: 15454
  },
  {
    name: "tamim",
    title: "This is tamim",
    roll: 423432
  },
  {
    name: "rahim",
    title: "This is shakib",
    roll: 234234
  },
  {
    name: "shakib",
    title: "This is tamim",
    roll: 34234
  }
];

export const Users = () => {
  const [term, setTerm] = useState("");

  const [searchResults, setSearchResults] = useState([]);

  useEffect(() => {
    const filteredItems = names.filter((item) => {
      return (
        item.name.toLowerCase().includes(term.toLowerCase()) ||
        item.title.toLowerCase().includes(term.toLowerCase())
      );
    });

    setSearchResults(filteredItems);
  }, [term]);

  return (
    <div>
      <input value={term} onChange={(e) => setTerm(e.target.value)} />
      <ul>
        {term &&
          searchResults &&
          searchResults.map((item, i) => (
            <li key={i}>
              {item.name} {item.title}
            </li>
          ))}
      </ul>
    </div>
  );
};

export default Users;
